
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String


def static "sampleKeywords.LoginKeyword.refreshBrowser"() {
    (new sampleKeywords.LoginKeyword()).refreshBrowser()
}

def static "sampleKeywords.LoginKeyword.clickElement"(
    	TestObject to	) {
    (new sampleKeywords.LoginKeyword()).clickElement(
        	to)
}

def static "sampleKeywords.LoginKeyword.getHtmlTableRows"(
    	TestObject table	
     , 	String outerTagName	) {
    (new sampleKeywords.LoginKeyword()).getHtmlTableRows(
        	table
         , 	outerTagName)
}
