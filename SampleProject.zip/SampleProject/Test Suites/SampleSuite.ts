<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>SampleSuite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>0b40fc78-e483-4ec8-85cf-3d6588d95ccc</testSuiteGuid>
   <testCaseLink>
      <guid>9e783545-b858-424d-9da2-fc6e1745f196</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_0001</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0a1c53df-3e45-4a9a-98f0-e0009e4901f5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC_0002</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>a4d6ec26-4d33-4fb4-a790-e674762e9817</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>6d1d9364-e4ff-4be6-b566-9ac55851749f</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>585a7fda-7a66-4889-8f5a-7fdae23d1bc6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/TC_DN Process flow</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
