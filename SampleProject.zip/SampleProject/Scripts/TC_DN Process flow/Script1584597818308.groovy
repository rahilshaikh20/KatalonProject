import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.testdata.InternalData as InternalData

InternalData data = findTestData('Data Files/InputData')

int rowCount = data.getRowNumbers();

println("Row count is: "+rowCount)

for (int i=0; i<rowCount;i++)
{

String PPMID = data.internallyGetValue('PPM', i);

String country = data.internallyGetValue('Country', i);

WebUI.deleteAllCookies()

WebUI.openBrowser('')

WebUI.navigateToUrl('https://ssd-asia.ad.diebold.com/')

WebUI.maximizeWindow()

WebUI.sendKeys(findTestObject('Page_Home/UserName'), 'rahil.shaikh')

WebUI.setEncryptedText(findTestObject('Page_Home/Password'), 'NX4G6o8aFBfmZ+xKA5T0mA==')

WebUI.click(findTestObject('Page_Home/LogInButton'))

'Select an option to be clicked. For example this selects the first option'
WebUI.click(findTestObject('Page_SelectOptions/Option1'))

WebUI.waitForPageLoad(90)

'Clicks on Country dropdown'
WebUI.click(findTestObject('Page_GetProject/CountryDropDown'))

'Enter Country Name to be searched'
WebUI.sendKeys(findTestObject('Page_GetProject/SearchOptionsByText'), country)

'Clicks on PPM dropdown'
WebUI.click(findTestObject('Page_GetProject/PPMIDDropDown'))

'Enter PPM ID to be searched'
WebUI.sendKeys(findTestObject('Page_GetProject/SearchOptionsByText'), PPMID)

WebUI.click(findTestObject('Page_GetProject/ValidateButton'))

'Verify text present on the screen'
WebUI.verifyTextPresent('Please specify your deliverable', false)

WebUI.closeBrowser()

}